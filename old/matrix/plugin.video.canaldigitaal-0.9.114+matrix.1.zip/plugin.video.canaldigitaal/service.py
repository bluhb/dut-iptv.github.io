from resources.lib.base.service import main
main()